output "s3_bucket_name" {
  description = "Назва S3-бакета для стейтів"
  value       = module.s3_backend.s3_bucket_name
}

output "dynamodb_table_name" {
  description = "Назва таблиці DynamoDB для блокування стейтів"
  value       = module.s3_backend.dynamodb_table_name
}

output "vpc_id" {
  description = "ID створеної VPC"
  value       = module.vpc.vpc_id
}

output "ecr_repository_url" {
  description = "URL ECR репозиторію"
  value       = module.ecr.repository_url
}

output "jenkins_release_name" {
  description = "Назва Helm release для Jenkins"
  value       = module.jenkins.jenkins_release_name
}

output "argocd_release_name" {
  description = "Назва Helm release для Argo CD"
  value       = module.argo_cd.argocd_release_name
}

